function getScore(arr) {
    let temp;
    let i = Math.floor((Math.random() * arr.length));
    temp = arr[i];
    console.log(i);
    console.log(temp);
    return temp;
  }
  
  const arrScores = [700, 820, 640, 460, 726, 850, 694, 721, 556];
  
  exports.handler = (event, context, callback) => {
    let creditScore = getScore(arrScores);
    callback(null, "Credit score pulled is: " + creditScore + ".");
  };